# Audixa — AI Audio Transcript & Chapter Maker
### Lightweight 2-Page Academic Project · English + Hinglish Support

Audixa is a fundamentals-first web application designed for speech-to-text transcription and automatic chapter generation from audio and video recordings. It is built using standard Python (Flask + SQLite) and native Web technologies (HTML5, Vanilla CSS, and Modern JavaScript) with zero frontend build tools.

---

## 🌟 Key Features

1. **Page 1: Upload & Transcribe (`/`)**
   - Drag-and-drop file upload supporting `.mp3`, `.wav`, `.m4a`, `.mp4`, `.flac`, `.aac`, `.webm`.
   - **Bilingual & Mixed-Language Support**:
     - 🌐 **Auto-detect (Hinglish)**: Ideal for Hindi-English code-switched speech.
     - 🇬🇧 **English**: Optimized for standard English.
     - 🇮🇳 **Hindi**: Optimized for standard Hindi.
   - **Model Precision Selector**: Choose between `tiny` (ultra-fast), `base` (recommended default), and `small` (high accuracy).
   - Real-time upload percentage tracking + animated Whisper AI processing state.
   - Recent transcripts quick-access history.

2. **Page 2: Simultaneous 3-Panel Editor (`/editor?id=...`)**
   - **All 3 sections visible simultaneously on one screen (no tabs or steps)**:
     - **Section A: Audio Player & Waveform**: Interactive WaveSurfer.js waveform visualizer with playback speed ($0.75\times - 2.0\times$), volume, $\pm 5$s skip, and spacebar play/pause.
     - **Section B: Interactive Transcript**: Time-synchronized segment cards that highlight and auto-scroll in real-time as the audio plays. Clicking any segment seeks the player. Inline editable text with debounced auto-saving to SQLite.
     - **Section C: Chapter Maker**: Auto-generated chapters based on conversational pause-gaps ($\ge 1.5$s) and temporal clustering. Includes a **"+ Add Chapter at current time"** button, inline title and timestamp editing, chapter deletion, and active chapter playback highlighting.
   - **Multi-Format Exports**: Export your work directly as **TXT**, **SRT Subtitles**, **WebVTT**, **YouTube Timestamp Chapters**, or **JSON**.

---

## 🏗️ Architecture & Tech Stack

```
                        ┌────────────────────────────────────────┐
                        │          Frontend (Browser)            │
                        │  HTML5 + Vanilla CSS + Vanilla JS      │
                        │  (WaveSurfer.js loaded via CDN script) │
                        └──────────────────┬─────────────────────┘
                                           │ HTTP / JSON API
                                           ▼
                        ┌────────────────────────────────────────┐
                        │          Backend (Flask)               │
                        │  app.py (Routes & Streaming)           │
                        └──────────┬──────────────────┬──────────┘
                                   │                  │
                                   ▼                  ▼
                    ┌─────────────────────────┐  ┌─────────────────────────┐
                    │  transcriber.py         │  │  db.py                  │
                    │  faster-whisper AI Engine│ │  SQLite (audixa.db)     │
                    └─────────────────────────┘  └─────────────────────────┘
```

| Layer | Technology | Rationale / Viva Justification |
| :--- | :--- | :--- |
| **Frontend** | Plain HTML5, CSS3, Vanilla JavaScript | No bundlers (Vite/Webpack/React) needed; easy to explain in viva, zero build overhead. |
| **Waveform** | `wavesurfer.js` (CDN script tag) | Pure client-side audio visualizer; lightweight and dependency-free. |
| **Backend** | Python **Flask** | Lightweight, direct template rendering, straightforward REST endpoints. |
| **Database** | **SQLite** (`sqlite3` built-in) | Serverless, single `.db` file, no separate database server required. |
| **AI Model** | **faster-whisper** (CTranslate2) | 4x faster than standard Whisper with 8-bit quantization on CPU; free and local (no API keys). |

---

## 🇮🇳 Language Support: English + Hinglish Note

- **Devanagari Script Output**: Whisper AI naturally outputs Hindi and mixed Hindi-English speech in **Devanagari script** (e.g., `"नमस्ते, आज हम coding करेंगे"`).
- **Model Sizes**:
  - `tiny`: Quick testing, lowest resource usage.
  - `base` *(Default)*: Excellent balance of speed and bilingual accuracy.
  - `small`: Best performance for heavy code-switched Hinglish.

---

## 📁 Project Structure

```
Audixa/
├── app.py                  # Main Flask application and REST endpoints
├── db.py                   # SQLite database initialization and CRUD operations
├── transcriber.py          # faster-whisper transcription & auto-chapter heuristic
├── audixa.db               # SQLite database file (created automatically)
├── requirements.txt        # Minimal Python dependencies
├── README.md               # Documentation and academic viva notes
├── templates/
│   ├── index.html          # Page 1: Upload and options page
│   └── editor.html         # Page 2: 3-panel simultaneous editor
├── static/
│   ├── css/
│   │   └── styles.css      # Dark-mode glassmorphic design system
│   └── js/
│       ├── upload.js       # File drag-and-drop and upload progress logic
│       └── editor.js       # Audio sync, transcript inline editing & chapters
└── uploads/                # Directory storing uploaded media files
```

---

## 🚀 Setup & Execution Guide

### 1. Prerequisites
- Python 3.10+ (Python 3.11 / 3.12 / 3.13 supported)

### 2. Installation

```bash
# Navigate to project folder
cd Audixa

# Create and activate virtual environment
python -m venv venv

# On Windows:
venv\Scripts\activate

# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Run the Application

```bash
python app.py
```

Open your browser and visit:
👉 **`http://127.0.0.1:5000`**

---

## 📝 REST API Reference

- `GET /` — Serves the Upload page (`index.html`)
- `GET /editor?id=<id>` — Serves the Editor page (`editor.html`)
- `POST /upload` — Uploads audio/video, executes Whisper, creates chapters, saves to SQLite
- `GET /transcript/<id>` — Returns full transcript, segments, and chapters for given ID
- `POST /save_transcript/<id>` — Updates edited transcript segments in SQLite
- `POST /save_chapters/<id>` — Updates and re-orders chapters in SQLite
- `GET /audio/<id>` — Streams stored audio file with HTTP byte-range support
- `GET /api/history` — Returns recent transcripts for dashboard drawer
